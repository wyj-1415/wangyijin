var imfonav = document.getElementsByClassName("imfomationnav")[0];
var changenav = document.getElementsByClassName("changenav")[0];
var imfo = document.getElementsByClassName("imfomation")[0];
var change = document.getElementsByClassName("change")[0];
change.style.display = "none";
imfo.style.display = "none";
imfonav.onclick = function (e) {
    e.preventDefault();
    change.style.display = "none";
    imfo.style.display = "block";
}
changenav.onclick = function (e) {
    e.preventDefault();
    imfo.style.display = "none";
    change.style.display = "block";
}
